import React from "react"

function Button() {
    return (
        <div>
            <button>
                Buy Now
            </button>
        </div>
    )
}

export default Button;