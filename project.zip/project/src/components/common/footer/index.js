import "./Footer.css";

function Footer(){
    return(
        <div className='footer_container'>
            YIFY© 2011-2024
        </div>
    )
}

export default Footer;
